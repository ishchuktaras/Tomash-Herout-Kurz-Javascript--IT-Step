function menu(){
	$('#menu ul ul').css('display','none');
	$('#menu > ul > li span').click(function(){
		$('#menu ul ul').css('display','block');
	});
}

menu();
